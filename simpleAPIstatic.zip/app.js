const express = require('express')
const app = express()
const PORT = 3000
const results = require('./data/results.json') // Include some data to emulate a database
// Point to static pages. Just use one if all files are in the same place but as code gets more complex, need to structure the folders

app.use(express.static('./public'))


// get some data from an object file based on the query string: /results/student?lName=whatever
app.get("/results/student/", (req, res) => {
  let score = []
  let lName = req.query.lName
  if (lName == undefined) return res.sendStatus(404) // not found

  score = results.filter(name => name.lName === lName)

  if (score.length == 0) return res.sendStatus(404) // not found
  else
    res.json(score)
})


// get some data from an object file based on the student ID param
// e.g. /results/student/5
app.get("/results/student/:id", (req, res) => {
  let score = []
  let id = Number(req.params.id) // Use param instead of query string
  if (isNaN(id))
    return res.sendStatus(400) // bad request

  score = results.filter(element => element.id === id)
  if (score.length == 0) return res.sendStatus(404) // not found
  else
    res.json(score) // This is just a string so not using res.json
})

// Get all results
app.get("/results/all", (req, res) => {
  res.json(results)
})


// You can provide a catch-all to respond with your response rather 
// than node's standard response which is an html file.
// If it makes it here then a page, middleware or route hasn't been found.
app.use((req, res, next) => {
  res.sendStatus(404)
})

app.listen(PORT, () => console.log(`Listening on port ${PORT}`))

